#include <stdio.h>

#include"header.h"

int main()
{

   password();   //call the function password

   AdmitList();   //call the function password


return 0;
}
