
#include <stdio.h>
#include <stdlib.h>

#include"header.h"

#define DATA_SIZE 1000

void AdmitList()
{
    /* Variable to store user content */
    char data[DATA_SIZE];


    FILE * fp;         // File pointer to hold reference to our file



    /*
     * Open file in w (write) mode.
     * create password.txt file
     */
    fp = fopen("AdmitList.txt", "w");


    /* fopen() return NULL if last operation was unsuccessful */
    if(fp == NULL)
    {

        printf("Unable to create file.\n"); // File not created hence exit
        exit(EXIT_FAILURE);
    }


    /* Input contents from user to store in file */
    printf("Enter contents to store in AdmitList.txt file : \n");

    for(int i=0; i<12; i++)
    {
    fgets(data, DATA_SIZE, stdin);

    fputs(data, fp);   //write the data on password.txt
    }


    fclose(fp); //close the file


}

