#!/bin/bash


#PART_01
echo part_01
echo "ENTER THE TEST USER"
read testUser
echo "$testUser" >>user.txt

echo enter test user to delete4
read deleteUser
sed  -i 's/$deleteUser//g' user.txt



#part_02
echo part_02
#create a dummy file with a size

echo "ENTER THE NAME OF DUMMY FILE"
read name
echo "ENTER THE SIZE OF DUMMY FILE"
read size

yes 123456789 | head  -$size > $name
chmod a+w $name

echo part_03

set -o




#part_04
#read the content of the file
echo part_04
echo enter the filename
read filename

while IFS= read -r line
do

    echo line:$LINENO $line
done < $filename

#part_05
echo part_05
 file_count()
 {
   local directory=$1
    Nof=$(ls $directory| wc -l)
    echo "$directory"
    echo "$Nof"

 }
echo ENTER THE DIRECTORY
read directory
if [ -e $directory ]
then 
	file_count $directory
else
        echo "no directory exist"
fi	


