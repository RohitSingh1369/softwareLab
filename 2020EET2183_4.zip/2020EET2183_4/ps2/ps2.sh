
echo "enter the username:"
read username
echo "enter the password:"
read password

#file=password.txt
#if [ -f $file ]
#then 
#	echo present
#	grep $username $file
#else
 #     echo file not exist
#fi      




echo welcome u logged in!

                   
while IFS= read -r line
do

    echo $line
done <prices.txt


echo "enter the no. of books and serial num you need"
read n s

if [ $n == 1 ]
then
	
	if [ $s == 1 ]
	then
       	echo "your bill is 399"
	fi
	if [ $s == 2 ]
	then
		echo "your bill is 599"
	fi
	if [ $s == 3 ]
	then 
	echo "your bill is 299"
	fi
        if [ $s == 4 ]
	then 
	echo "your bill is 351"
	fi
    if [ $s == 5 ]
    then
    echo "your bill is 999"
    fi
    
    case $n in 
	    [$n==2])
		    echo "enter the s no. of both book"
		    read $a $b
		    if [ $a == 1 ] && [ $b == 2 ]
		    then 
			    echo "your bill is 998"
		    fi
		    if [ $a == 1] && [ $b == 3 ]
		    then 
			    echo "your bill is 698"
		    fi
		    if [ $a == 1 ] && [ $b == 4 ]
		    then 
			    echo "your bill is 750"
		    fi
		    if [ $a == 1] && [ $b == 5 ]
		    then 
			    echo "your bill is 1398"
		    fi
		    if [ $a == 2 ] && [ $b == 3]
		    then 
			    echo "your bill is 898"
		    fi
		    if [ $a == 2 ] && [ $b == 4 ]
		    then 
			    echo "your bill 950"
		    fi
		    if [ $a == 2 ] && [ $b == 5 ]
		    then 
			    echo "your bill is 1598"
		    fi
		    ;;
	    *)
    esac
