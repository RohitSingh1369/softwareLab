#include <stdio.h>


void MergeArr(int num1[], int num2[],int m, int n)  //mergeArr function to sort two array
   {
   int k=0;   // initialize counter for num2

     for(int i=0; i<m+n; i++)   //loop to transverse the num1
     {
        if(num1[i]>num2[k] && k<n)     // comparing corresponding elemnets of both array
        {
            for(int j=m+n-1; j>i; j--)    //loop to shift the elements after i;
            {
               num1[j]=num1[j-1];    //shifting the array when element of num1>num2
            }

            num1[i]=num2[k];      //and copy that element of num2 in num 1;

            k++;   //increase the num2 counter by 1
        }
     }
     if(k!=n)           // transfer all remaining elements of num2 to num1
      {
        for(int i=m+k; i<m+n; i++)   // from m+k to m+n
        {
          num1[i]=num2[i-m];         //copy num2 to num1
        }
      }

         printf("final sorted array num1: \n");   //frint the final array

    for(int h=0; h<m+n; h++)           // print whole m+n elements of array num1
    {
       printf("%d ",num1[h]);
    }

    printf("\n");

   }


int main(){

    int m,n;

    printf("Enter the size of array num1: ");     //Enter the size of array num1
    scanf("%d", &m);

    printf("Enter the size of array num2: ");     //Enter the size of array num2
    scanf("%d", &n);


    int num1[m+n],num2[n];        // declare array num1 and num2

    printf("enter first %d elements of num1 and next %d elements of num2 :\n ",m,n) ;

    for(int i=0; i<m; i++)       //taking first m input for
     {                           //array num1
     scanf("%d",&num1[i]);
     }

    for(int i=0; i<n; i++)       //taking n elements as input
     {                           //for num2
     scanf("%d",&num2[i]);
     }

    for(int h=m; h<m+n; h++)    // assigning zero to the
     {                          // garbage values of num1
       num1[h] = 0;
     }


 MergeArr(num1,num2,m,n);   //mergeArr function to merge two array

     return 0;
 }


