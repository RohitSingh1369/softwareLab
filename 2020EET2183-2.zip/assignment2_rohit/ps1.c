#include <stdio.h>
#include <math.h>

int count_even( int n ,int r[n][n]){      // count_even function defined to find out number of even integer in matrix

    int k=0, i, j;             // k is count for even number  and i and j are the rows and colomns

       for(i=0; i<n; i++)   //loop for rows
       {
          for(j=0; j<n; j++)  //loop for colomns
          {
             if(r[i][j]%2 == 0)   // check if remainder is 0
             {
                k++;    //increase count by 1
             }
          }
       }

return k;     //return total count
}


void pft_sqr( int n ,int r[n][n]){    //perfect square functon declaration pft_sqr

       int  i, j;
       int iVar;       //defining variable iVar and fVar for checking of square root
       double fVar;
       double num;   //num is temparary varibale

       printf("perfect square in diagonal of matrix: ");

       for(i=0; i<n; i++)   //for loop for rows to check perfect square
       {
          for(j=0; j<n; j++)  //foe loop for colomns to check perfect square
          {
           if(i==j || i+j==n-1) //identifing the diagonal elements
           {
             num = r[i][j];    //temp variable stroing value of matrix element in double data type
             fVar = sqrt(num); //fVar is double data type storing the the square root
             iVar=fVar; //load double data type into integer data type

             if(iVar == fVar)   //check if fVar is integer
             {
                printf("%d ", r[i][j]); //print the perfect square
             }
            }
          }
       }
       printf("\n");

}



void glb_MaxMin( int n ,int r[n][n]){   //glb_MaxMin function to find min and max values

    int Max = r[0][0], Min = r[0][0];    //assign the initial values first element of matrix to max and min
    int   i, j;

       for(i=0; i<n; i++)           //for loop for rows
       {
          for(j=0; j<n; j++)        //for loop for colomns
          {
             if(r[i][j] > Max)      // if matirx element is greater than Max
             {
                Max = r[i][j];      //store that element in Max
             }
             else if(r[i][j] <Min)  // if matirx element is smaller than Max
             {
                Min = r[i][j];      //store that element in Min
             }
          }
       }
printf("max and min values in matrix: %d, %d \n", Max, Min);  //print Max and Min elements
}

/*

bool Isprime(int num)     // defineing Isprime function to check whether function is prime or not
{
  int k=0;   //intialize counter to check remainder is zero for any number

  for(int i=2; i<num; i++)   //loop to check if remainder is zero
  {
     if(num % i == 0)     //codition on rremainder
     {
      k++;    //increase counter by one
     }
  }
   if(k==0)    //by checking counter equal to means
   {
   return true;   //number is prime and return true
   }
   else     //else return false
   {
   return false;
   }
}


void Prim_MaxMin( int n ,int r[n][n]){   //prim_MaxMin function to find min and max prime number

    int Max = r[0][0], Min = r[0][0];    //assign the initial values first element of matrix to max and min
    int   i, j;


       for(i=0; i<n; i++)           //for loop for rows
       {
          for(j=0; j<n; j++)        //for loop for colomns
          {
             if(Isprime(r[i][j])==1)
             {
                 if(r[i][j] > Max)      // if matirx prime element is greater than Max
                 {
                   Max = r[i][j];      //store that prime element in Max
                 }
                 else if(r[i][j] <Min)  // if matirx prime element is smaller than Max
                 {
                   Min = r[i][j];      //store that prime element in Min
                 }
             }
          }
       }
printf("max and min prime number in matrix: %d, %d ", Max, Min);  //print Max and Min prime elements
}

*/


int main(){

    printf("Enter the size of square matrix: ");     //Enter the size of square matrix
    int n;
    scanf("%d", &n);      //taking size of matrix in input


    int r[n][n];   //declaring integer square matrix
    int a;
    int b;

        for (a=0; a<n; a++){     //for loop for rows to take input

            for (b=0; b<n; b++){    //for loop for colomns to take input

            printf("enter the arr[%d,%d] element: " ,a,b);

            scanf("%d",&r[a][b]);    //scan the value of each element of matrix
        }
    }

    /* Ps1.1 counting the total evne interger in 2d array */

   printf("Total number of even number in matrix: %d \n" ,count_even(n,r));

    /* Ps1.2 counting the total evne interger in 2d array */

   pft_sqr(n,r);

   /* Ps1.3 counting the total evne interger in 2d array */

   /* Prim_MaxMin(n,r); */

   /* Ps1.4 counting the total evne interger in 2d array */

   glb_MaxMin(n,r);



     return 0;

}
