# A basic C2C e-commerce application made for the school project that allows users to sell, buy and rate products. Kivy used for the desktop application and MySQL used for the Database.
