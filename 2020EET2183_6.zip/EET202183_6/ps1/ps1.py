
# Function to convert Decimal number
# to Binary number
def decimalToBinary(n):
    return bin(n).replace("0b", "")

def countSetBits(num):
    # convert given number into binary
    # output will be like bin(11)=0b1101
    binary = bin(num)
    # now separate out all 1's from binary string
    # we need to skip starting two characters
    # of binary string i.e; 0b
    setBits = [ones for ones in binary[2:] if ones == '1']

    return len(setBits)



# Driver code
if __name__ == '__main__':
    num1 = int(input("Enter the first number: "))
    num2 = int(input("Enter the second number: "))
    bin1 = decimalToBinary(num1)
    bin2 = decimalToBinary(num2)
    count1 = countSetBits(num1)
    count2 = countSetBits(num2)

    print("\nOUTPUT:")
    print("binary repreentation of {} = {}".format(num1, bin1))
    print("binary repreentation of {} = {}".format(num2, bin2))

    k = count1 - count2
    if k < 0:
        k = k * -1

    if k == 0:
        print("Sample Output 1: Bit Balanced! |{}| - |{}| = |{}-{}| = {}".format(num1,num2,count1,count2,k))
        print("Hence both contain equal number 1s, hence the output\n")

    else:
        print("Sample Output 1: Bit Biased! |{}| - |{}| = |{}-{}| = {}".format(num1, num2, count1, count2, k))
        print("Hence both contain different number of 1s, hence the output\n")


